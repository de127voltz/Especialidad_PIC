/*
  LED Intermitente en RD0
*/

void main() {

  TRISD.F0=0;      // RD0 como salida digital
  PORTD.F0=0;      // RD0 valor inicial cero logico
  
  while(1)         // loop Programa principal
  {
    PORTD.F0=1;    // se activa RD0
    Delay_ms(1000);// retardo 1s
    PORTD.F0=0;    // RD0 se desactiva
    Delay_ms(1000);// despues de 1s se activa nuevamente
  }
}