/*
  Proceso de Mezclado
  RD0     M1
  RD1     Y1
  RD2     M3
  RD3     Y2
  RD4     M2
*/

void main() {
   TRISD = 0B00000000;  //  Se configura de RD0 a RD4 como salida digital
   PORTD = 0B00000000;  // se inicializa el valor digital de las salidas.
   
   while(1)            // loop
   {
     PORTD = 0B00000001;  // se activa M1
     Delay_ms(3000);      // 3s despues de desactiva M1 y se cierra valvula Y1
     PORTD = 0B00000010;
     Delay_ms(3000);      // 3s despues se cierra y1 y se activa m3
     PORTD = 0B00000100;
     Delay_ms(5000);      // 5s despu�s se detiene m3 y se abre Y2
     PORTD = 0B00001000;
     Delay_ms(3000);
     PORTD = 0B00010000;  // se cierra y2 y se activa m2
     Delay_ms(3000);
   }
}