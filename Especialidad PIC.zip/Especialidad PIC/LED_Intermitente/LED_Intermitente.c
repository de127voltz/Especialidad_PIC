/*
  LED intermitente
*/

void main() {

    TRISD.F0 = 0;      // RD0 se configura como salida digital


   while(1)
   {
    PORTD.F0 = 1;      // RD0 se activa en 1 l�gico
    Delay_ms(1000);    // retardo 1s
    PORTD.F0 = 0;      // se apaga RD0 en 0 logico
    Delay_ms(1000);    // retardo 1s
    }
}