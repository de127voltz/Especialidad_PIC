
// Este programa permite controlarun motor a pasos
// PULSE RD0
// DIR   RD1
// EN    RD2
// RD3   Boton      para cambiar el sentido de giro

void main() {
    TRISD=0B00001000;      // se configuran puertos de E/S
    PORTD=0;               // se inicializa el puerto
    
    while(1)
    {
     if(PORTD.F3 == 1)      // esta presente el boton
     {
       PORTD.F1=1;          // giro en una direcci�n
       PORTD.F0=1;          // se genera el pulso
       Delay_ms(10);
       PORTD.F0=0;          // se genera el pulso
       Delay_ms(10);
     }
     else
     {
      PORTD.F1=0;          // giro en otra direcci�n
       PORTD.F0=1;          // se genera el pulso
       Delay_ms(10);
       PORTD.F0=0;          // se genera el pulso
       Delay_ms(10);
     }
    }
}