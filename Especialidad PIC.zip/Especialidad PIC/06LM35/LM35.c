/*
  Este programa lee una entrada anlogica
  del sensor LM35
*/
      int adc0,mv,temp;
void main() {
     TRISD = 0B00000000;        // RD0 y RD1 como salidas digitales
     PORTD = 0B00000000;        // se inicializa el valor de RD0 y RD1
     TRISA.F0 = 1;              // AN0 como entrada
     ANSEL = 0B00000001;        // AN0= entrada analogica
     ADC_Init();
     
     while(1)
     {
      adc0 = ADC_Read(0);       // se lee adc0  0-1023
      mv = (adc0*5)/1023;       // convertimos valor digital a volts
      temp = mv *100;           // 10mv = 1�C
      if(temp < 35)
      PORTD = 0B00000001;       // se activa led verde
      if(temp > 35)
      PORTD = 0B00000010;       // se activa led rojo

      
     }
}