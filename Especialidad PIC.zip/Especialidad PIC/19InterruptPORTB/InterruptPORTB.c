
    int ciclo=125;         // LED incia con  50% de intensidad

void main() {
      TRISB=0B00000011;       // RB0 y RB1 como entradas
      PORTB=0;
      ANSELH=0;
      WPUB=0B00000011;        // se activan resistencias de pull up en RB0 y RB1
      PWM1_Init(5000);
      PWM1_Start();
      OPTION_REG.F7=0;        // las resistencias de pull up se activan individual
      INTCON = 0B10001000;    // Se habilitan las int en portb por cambio de estado
      IOCB = 0B00000011;      // RB0 y RB1 se habilita la int

      while(1)
      {
       /// el programa principal queda completamente vacio
      }
}


void interrupt()
{
       INTCON.F7=0;     // deshabilitamos todas las interrupciones
       if(PORTB.F1==0)
       {
        ciclo= ciclo+5;
        if(ciclo >= 255)
        ciclo=255;
       }
       if(PORTB.F0==0)
       {
        ciclo= ciclo-5;
        if(ciclo <= 0)
        ciclo=0;
       }
       PWM1_Set_Duty(ciclo);
       INTCON = 0B10001000;    // Se habilitan las int en portb por cambio de estado
       Delay_ms(100);
}