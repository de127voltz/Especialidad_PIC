sbit LCD_RS at RD4_bit;
sbit LCD_EN at RD5_bit;
sbit LCD_D7 at RD3_bit;
sbit LCD_D6 at RD2_bit;
sbit LCD_D5 at RD1_bit;
sbit LCD_D4 at RD0_bit;

// Pin direction
sbit LCD_RS_Direction at TRISD4_bit;
sbit LCD_EN_Direction at TRISD5_bit;
sbit LCD_D7_Direction at TRISD3_bit;
sbit LCD_D6_Direction at TRISD2_bit;
sbit LCD_D5_Direction at TRISD1_bit;
sbit LCD_D4_Direction at TRISD0_bit;

int contador=0;
char count[7];

void main() {
    TRISB=0B00000001;     //RB0 como entrada digital
    ANSELH=0;
    PORTB=0;
    WPUB=0B00000001;        // se activa resistencia de pull up en RB0
    OPTION_REG.F7=0;        // confg resistencias pull up sera de forma individual
    OPTION_REG.F6=0;        // se configurar� la interrupcion en flanco de bajada
    INTCON = 0B10010000;     // se activa GIE e INTE
    
    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    Lcd_Out(1,1,"  Contador  ");
    IntToStr(contador,count);
    Lcd_Out(2,1,count);
    
    while(1)
    {
    IntToStr(contador,count);
    Lcd_Out(2,1,count);
    Delay_ms(100);
    }
}

void interrupt()
{
 INTCON.GIE=0;
 if(INTCON.INTF == 1)   // ocurrio una interrupcion?
 {
   contador++;
   Delay_ms(100);
 }
 INTCON = 0B10010000;     // se activa GIE e INTE
}