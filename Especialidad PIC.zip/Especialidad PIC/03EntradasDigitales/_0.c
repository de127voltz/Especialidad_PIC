/*
  Entradas digitales
  se asignara el valor de una entrada digital
  a una salida digital de RD0 a RD1
*/

void main() {
   TRISD = 0B00000001;      // RD0 como entrada y RD1 como salida
   PORTD.F1=0;              // se iniciliaza el valor de RD1
   
   while(1)
   {
     if(PORTD.F0 == 1)      // RD0 esta presionado? esta en 1?
     {
      PORTD.F1=1;           // PORTD=0B00000010;
     }
     else
     {
      PORTD.F1=0;           //No, no esta en 1, por tanto se apaga RD1
     }
   }
   
}