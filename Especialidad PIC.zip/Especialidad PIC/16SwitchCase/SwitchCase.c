
         char DatoIN;
void main() {
         TRISD = 0B00000000;               // RD0 y RD1 como salidas digitales
         PORTD = 0;                        // inicializamos el puerto
         UART1_Init(9600);
         Delay_ms(100);                    // inicilizar puerto serie a 9600

         while(1)
         {
          if(UART1_Data_Ready() > 0)       // llegaron datos?
          {
           DatoIN = UART1_Read();          // se lee el dato de entrada

           switch(DatoIN)
           {
            case 'A':
               PORTD.F0=1;                 // se activa el RD0
            break;
            case 'B':
               PORTD.F0=0;                 // se desactiva el RD0
            break;
            case 'C':
               PORTD.F1=1;                 // se activa el RD1
            break;
            case 'D':
               PORTD.F1=0;                 // se desactiva el RD1
            break;
            default:
               PORTD=0;                  // se apagan RD0 y RD1
            break;
           }
          }
         }
}