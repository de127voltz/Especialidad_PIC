/*
  Programa de llenado de tanque
*/

void main() {
   TRISD = 0B00000011;      // RD0 y RD1 como entradas digitales RD2 como salida
   
   while(1)
   {
    PORTD.F2 = 0;           // inicia la valvula cerrada
    if(PORTD.F0 == 0 && PORTD.F1 == 0)
    {
      PORTD.F2 = 1;         // se activa la valvula
    }
    if(PORTD.F0 == 1 && PORTD.F1 == 0)
    {
      PORTD.F2 = 1;         // se activa la valvula
    }
   }
}