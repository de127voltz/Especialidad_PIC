/* este programa lee una se�al analogica y la representa en
binario con 10 LEDs */
 unsigned int adc0;
void main() {
  TRISD = 0B00000000;    // PORTD como salidas
  TRISB = 0B00000000;    // PORTB como salidas digitales
  ANSELH = 0;            // no se utilizan entradas analogicas
  TRISA= 0B00000001;     // AN0 como entrada
  ANSEL = 0B00000001;    // AN0  analogica
  ADC_Init();            // inicializamos el ADC
  
  while(1)
  {
    adc0 = ADC_Read(0);     // se lee AN0
    PORTB = adc0;           // se asignan primeros 8 bits
    PORTD = adc0 >> 8;      // se asignan los 2 bits mas altos
  }
}